// The colorizeElement-function will read the data-lang-attribute
// from the element to select the correct language mode. In this
// sample it is text/css.
monaco.editor.colorizeElement(document.getElementById('code'));
