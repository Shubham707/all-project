<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

		<div class="col-md-12"><!-- All Sent Received Transferred -->
				<div class="panel panel-default">
					<div class="panel-body tabs">
						<ul class="nav nav-tabs">
							<li class="active"><a href="#tab1" data-toggle="tab" aria-expanded="true">All</a></li>
							<li class=""><a href="#tab2" data-toggle="tab" aria-expanded="false">Sent</a></li>
							<li class=""><a href="#tab3" data-toggle="tab" aria-expanded="false">Received</a></li>
							<li class=""><a href="#tab4" data-toggle="tab" aria-expanded="false">Transferred</a></li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane fade active in scrolling" id="tab1">
								<h4>Tab 1</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget rutrum purus. Donec hendrerit ante ac metus sagittis elementum. Mauris feugiat nisl sit amet neque luctus, a tincidunt odio auctor.</p>
								
							</div>
							<div class="tab-pane fade scrolling" id="tab2">
								<h4>Tab 2</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget rutrum purus. Donec hendrerit ante ac metus sagittis elementum. Mauris feugiat nisl sit amet neque luctus, a tincidunt odio auctor.</p>
							</div>
							<div class="tab-pane fade scrolling" id="tab3">
								<h4>Tab 3</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget rutrum purus. Donec hendrerit ante ac metus sagittis elementum. Mauris feugiat nisl sit amet neque luctus, a tincidunt odio auctor.</p>
							</div>
							<div class="tab-pane fade scrolling" id="tab4">
								<h4>Tab 1</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget rutrum purus. Donec hendrerit ante ac metus sagittis elementum. Mauris feugiat nisl sit amet neque luctus, a tincidunt odio auctor.</p>
							</div>
						</div>
					</div>
				</div><!--/.panel-->
			</div>
<?php include'footer.php'; ?>