<?php
	include'../common.php';
	if($user_session==true){
	logout();
	}
?>