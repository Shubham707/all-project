<?php
	include_once('common.php');
	logout();
	exit();
?> 